# CVAR bandits

## ./bandits
Bandits use nested classes. The base class is defined in 'bandit_base.py'. Child classes are defined in 'bandit_foo.py'.

## ./utils
Contains utility functions the bandit classes.