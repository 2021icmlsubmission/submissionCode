"""
This file contains utility functions for bandits 
"""
import numpy as np
import itertools

def empirical_cvar(samples, alpha):
    """
    Simple empirical estimation of the CVaR from quantile 0 to alpha
    @param samples: i.i.d. samples
    @type samples: list, 1D
    @param alpha: CVaR's alpha level
    @type alpha: float
    @return: empirical CVaR @ alpha
    @rtype: float
    """
    n = len(samples)
    sorted_samples = sorted(samples)
    n_alpha = int(np.ceil(n * alpha))
    to_n_alpha_values = sorted_samples[:n_alpha]
    emp_cvar = np.mean(to_n_alpha_values)
    return emp_cvar

def moment_empirical_cvar(samples, alpha):
    """
    Quantile 0 to alpha CVaR moment based estimator as described in https://arxiv.org/abs/1401.1123
    @param samples: i.i.d. samples
    @type samples: list, 1D
    @param alpha: CVaR's alpha level
    @type alpha: float
    @return: empirical CVaR @ alpha
    @rtype: float
    """
    sorted_samples = np.sort(samples)
    n = int(alpha * len(samples))
    return samples[n] + 1 / alpha / len(samples) * (sorted_samples[:n] - samples[n]).sum()
    
if __name__ == '__main__':
    pass
