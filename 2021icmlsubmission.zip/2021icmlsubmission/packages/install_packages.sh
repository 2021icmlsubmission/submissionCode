#!/bin/bash
echo "### PACKAGE INSTALLATION ###"
for repo in ./*
  do
    if [ "$repo" != "./${0}" ];then  # do not consider the .sh
      rm -rf "${repo}/*.egg-info"  2> /dev/null  # remove previous installation repo
      pip3 install -e ./$repo
    fi
  done